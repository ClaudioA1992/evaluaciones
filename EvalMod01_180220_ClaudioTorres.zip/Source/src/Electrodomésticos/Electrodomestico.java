package Electrodom�sticos;

public class Electrodomestico {
	
	//Atributos
	
	protected double precio;
	protected String color;
	protected char consumo_e;
	protected int peso_kg;
	
	protected final static String COLOR_DEF="blanco";
	protected final static char CONSUMO_ENERGETICO_DEF='F';
	protected final static double PRECIO_BASE_DEF=100000;
	protected final static int PESO_DEF=5;
	
	char letraConsumo[] = new char [] {'A','B','C','D','E','F'};
	
	//Getters y setters
 	
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public char getConsumo_e() {
		return consumo_e;
	}
	public void setConsumo_e(char consumo_e) {
		this.consumo_e = consumo_e;
	}
	public int getPeso_kg() {
		return peso_kg;
	}
	public void setPeso_kg(int peso_kg) {
		this.peso_kg = peso_kg;
	}
	
	
	//Constructores

	public Electrodomestico(double precio, int peso_kg) {
		super();
		this.precio = precio;
		this.peso_kg = peso_kg;
	}	   
	
	public Electrodomestico(double precio, String color, char consumo_e, int peso_kg) {
		super();
		this.precio = precio;
		this.color = color;
		this.consumo_e = consumo_e;
		this.peso_kg = peso_kg;
	}
	
	public Electrodomestico() {
		super();
	}
	
	
	//Metodos asignados
	
	public char comprobarConsumoEnergetico (char letra) {
		Character.toUpperCase(letra);
		if (letra=='A' || letra=='B' || letra=='C' || letra=='D' || letra=='E' || letra=='F') {
			return letra;
	}    
	    else {	    	
	    	return 'F';
	    }
	    
	}    
	    
	public boolean comprobarColor (String color) {
		color.toLowerCase();
		if (color.equals("blanco") || color.equals("negro") || color.equals("rojo") || color.equals("azul") || color.equals("gris")) {
			return true;
	}    
	    else {	    	
	    	return false;
	    }
	    
	}    
	
	public double precioFinal(char letra, int peso) {
		Character.toUpperCase(letra);
		switch (letra) {
		    case 'A': precio=PRECIO_BASE_DEF+85000;
		    break;
		    case 'B': precio=PRECIO_BASE_DEF+70000;
		    break;
		    case 'C': precio=PRECIO_BASE_DEF+50000;
		    break;
		    case 'D': precio=PRECIO_BASE_DEF+40000;
		    break;
		    case 'E': precio=PRECIO_BASE_DEF+25000;
		    break;
		    case 'F': precio=PRECIO_BASE_DEF+8500;
		    break;
		}
		if (peso>=0 && peso<=19) {
		    precio=precio+8500; 		
		}
		else if (peso>19 && peso <50) {
			precio=precio+40000;
		}
		else if (peso>=50 && peso<80) {
			precio=precio+70000;
		}
		else if (peso>=80) {
			precio=precio+85000;			
		}
		
		return precio;
				
	}

}
