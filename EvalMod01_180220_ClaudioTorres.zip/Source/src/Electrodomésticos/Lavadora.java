package Electrodom�sticos;

public class Lavadora extends Electrodomestico {

	protected int carga;
	
	protected static final int carga_def=5;
	

	//Constructores
	
	public Lavadora(double precio, int peso_kg) {
		super(precio, peso_kg);
		this.precio=precio;
		this.peso_kg=peso_kg;
	}

	public Lavadora() {
		super();
	}

	public Lavadora(double precio, String color, char consumo_e, int peso_kg, int carga) {
		super(precio, color, consumo_e, peso_kg);
		this.precio=precio;
		this.color=color;
		this.consumo_e=consumo_e;
		this.peso_kg=peso_kg;
		this.carga=carga;
	}
    
	
	//Getter y setter
	
	public int getCarga() {
		return carga;
	}

	public void setCarga(int carga) {
		this.carga = carga;
	}
	
    

	
	//Metodo
	
	public double precioFinalLav(char letra, int peso, double precio, int carga) {
		this.carga=carga;
		Character.toUpperCase(letra);
		switch (letra) {
		    case 'A': precio=PRECIO_BASE_DEF+85000;
		    break;
		    case 'B': precio=PRECIO_BASE_DEF+70000;
		    break;
		    case 'C': precio=PRECIO_BASE_DEF+50000;
		    break;
		    case 'D': precio=PRECIO_BASE_DEF+40000;
		    break;
		    case 'E': precio=PRECIO_BASE_DEF+25000;
		    break;
		    case 'F': precio=PRECIO_BASE_DEF+8500;
		    break;
		}
		
		if (peso>=0 && peso<=19) {
		    precio=precio+8500; 		
		}
		else if (peso>19 && peso <50) {
			precio=precio+40000;
		}
		else if (peso>=50 && peso<80) {
			precio=precio+70000;
		}
		else if (peso>=80) {
			precio=precio+85000;			
		}
		
		
		if (carga>30) {
			precio=precio+40000;	
		}
		
		return precio;
	}
		
		
		
}

