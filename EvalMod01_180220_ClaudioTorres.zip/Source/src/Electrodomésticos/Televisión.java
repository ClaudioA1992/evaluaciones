package Electrodom�sticos;

public class Televisi�n extends Electrodomestico {
	
	//Atributos

	protected int resolucion;
	protected boolean sintonizadorTDT;
	
	protected final static int resolucion_def=20;
	protected final static boolean sintonizador_def=false;
	
	
	//Constructores
	
	public Televisi�n() {
		super();
	}
	
	public Televisi�n (double precio, int peso_kg) {
		super();
		this.precio=precio;
		this.peso_kg=peso_kg;
	}
    
	public Televisi�n(double precio, String color, char consumo_e, int peso_kg, int resolucion, boolean sintonizadorTDT) {
		super(precio, color, consumo_e, peso_kg);
		this.precio=precio;
		this.color=color;
		this.consumo_e=consumo_e;
		this.peso_kg=peso_kg;
		this.resolucion=resolucion;
		this.sintonizadorTDT=sintonizadorTDT;
	}
	
	
	//Getters y setters

	public int getResolucion() {
		return resolucion;
	}

	public void setResolucion(int resolucion) {
		this.resolucion = resolucion;
	}

	public boolean isSintonizadorTDT() {
		return sintonizadorTDT;
	}

	public void setSintonizadorTDT(boolean sintonizadorTDT) {
		this.sintonizadorTDT = sintonizadorTDT;
	}

	public static int getResolucionDef() {
		return resolucion_def;
	}

	public static boolean isSintonizadorDef() {
		return sintonizador_def;
	}

	
	//Metodo

	public double precioFinalTel(char letra, int peso, double precio, int resolucion, boolean sintonizadorTDT) {
		
		Character.toUpperCase(letra);
		switch (letra) {
		    case 'A': precio=PRECIO_BASE_DEF+85000;
		    break;
		    case 'B': precio=PRECIO_BASE_DEF+70000;
		    break;
		    case 'C': precio=PRECIO_BASE_DEF+50000;
		    break;
		    case 'D': precio=PRECIO_BASE_DEF+40000;
		    break;
		    case 'E': precio=PRECIO_BASE_DEF+25000;
		    break;
		    case 'F': precio=PRECIO_BASE_DEF+8500;
		    break;
		}
		    
		if (peso>=0 && peso<=19) {
		    precio=precio+8500; 		
		}
		else if (peso>19 && peso <50) {
			precio=precio+40000;
		}
		else if (peso>=50 && peso<80) {
			precio=precio+70000;
		}
		else if (peso>=80) {
			precio=precio+85000;			
		}
		
		
		if (resolucion>40) {
			precio=precio+(precio*1.3);
		}
		
		if (sintonizadorTDT==true){		
			precio=precio+45000;
		}			
		
		return precio;
	}			
	
}
