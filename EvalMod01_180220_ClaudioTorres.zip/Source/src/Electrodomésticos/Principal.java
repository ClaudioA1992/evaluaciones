package Electrodom�sticos;

public class Principal {

	public static void main(String[] args) {
		
		double sumaElec=0, sumaLav=0, sumaTv=0;
		
		Electrodomestico ElectrodomesticoArr[] = new Electrodomestico[10];
		
		ElectrodomesticoArr[0] = new Electrodomestico(100000, "negro", 'C', 20);
		ElectrodomesticoArr[1] = new Lavadora(100000, "rojo", 'D', 30, 30);
		ElectrodomesticoArr[2] = new Lavadora(100000, "blanco", 'A', 40, 30);
		ElectrodomesticoArr[3] = new Televisi�n(100000, "azul", 'B', 50, 30, true);
		ElectrodomesticoArr[4] = new Lavadora(100000, "gris", 'F', 60, 20);
		ElectrodomesticoArr[5] = new Televisi�n(100000, "rojo", 'E', 50, 30, true);
		ElectrodomesticoArr[6] = new Televisi�n(100000, "blanco", 'A', 60, 45, true);
		ElectrodomesticoArr[7] = new Televisi�n(100000, "blanco", 'C', 55, 35, false);
		ElectrodomesticoArr[8] = new Lavadora(100000, "azul", 'D', 57, 27);
		ElectrodomesticoArr[9] = new Lavadora(100000, "rojo", 'B', 60,40);
		
		for (int i=0; i<10; i++) {
			
			if (ElectrodomesticoArr[i] instanceof Electrodomestico && (!(ElectrodomesticoArr[i] instanceof Lavadora)) && (!(ElectrodomesticoArr[i] instanceof Televisi�n))) {
				
				sumaElec=sumaElec+ElectrodomesticoArr[i].precioFinal(ElectrodomesticoArr[i].getConsumo_e(), ElectrodomesticoArr[i].getPeso_kg());
			}
			
			else if (ElectrodomesticoArr[i] instanceof Lavadora && ElectrodomesticoArr[i] instanceof Electrodomestico && (!(ElectrodomesticoArr[i] instanceof Televisi�n))) {
				
				Lavadora lavadora = (Lavadora) ElectrodomesticoArr[i];	
				sumaLav=sumaLav+(lavadora.precioFinalLav(lavadora.getConsumo_e(), lavadora.getPeso_kg(), lavadora.getPrecio(), lavadora.getCarga()));
            
			}
			
			else if (ElectrodomesticoArr[i] instanceof Televisi�n && ElectrodomesticoArr[i] instanceof Electrodomestico && (!(ElectrodomesticoArr[i] instanceof Lavadora)))	{
				Televisi�n television = (Televisi�n) ElectrodomesticoArr[i];
				sumaTv=sumaTv+(television.precioFinalTel(television.getConsumo_e(), television.getPeso_kg(), television.getPrecio(), television.getResolucion(), television.isSintonizadorTDT()));
			
			}
			
		}
			


		    System.out.println("La suma del valor de los electrodom�sticos (no lavadoras ni tvs) es: "+sumaElec);
			    
			System.out.println("La suma del valor de las lavadoras es: "+sumaLav);
			
			System.out.println("La suma del valor de los televisores es: "+sumaTv);
			
			System.out.println("La suma total de los electrodom�stivos es: "+(sumaElec+sumaLav+sumaTv));		   
			
	}
		
}
	
